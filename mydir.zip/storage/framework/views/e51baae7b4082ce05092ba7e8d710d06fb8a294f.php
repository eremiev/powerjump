<!-- Home -->

<div class="home">

    <!-- Home Slider -->
    <div class="home_slider_container">
        <div class="owl-carousel owl-theme home_slider">

            <!-- Slide -->
            
                
                
                    
                        
                            
                                
                                    
                                        
                                        
                                    
                                    
                                
                            
                        
                    
                
            

            <!-- Slide -->
            <div class="slide">
                <div class="background_image" style="background-image:url(<?php echo e(url('images/01.jpg')); ?>)"></div>
                <div class="slide_container">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="slide_content">
                                    <div class="slide_title">
                                        <div></div>
                                        <div><span>Power Jump</span></div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>

        <!-- Home Slider Dots -->
        <div class="home_slider_dots_container">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="home_slider_dots">
                            <ul id="home_slider_custom_dots" class="home_slider_custom_dots d-flex flex-row align-items-start justify-content-start">
                                
                                
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>