<?php $__env->startSection('header'); ?>
    Проекти -> Промяна на проект
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
    <?php echo Form::open(['route' => ['admin.projects.update', $project->id],
                           'method' => 'PUT',
                           'class'=>'form-horizontal',
                           'files' => true]); ?>

    <div class="form-group">
        <label for="title">Заглавие</label>
        <input type="text" class="form-control" name="title" id="title" value="<?php echo e($project->title); ?>">
    </div>

    <div class="form-group">
        <label for="description">Описание</label>
        <textarea id="description" name="description"><?php echo e($project->description); ?></textarea>

    </div>

    <div class="form-group">
        <label for="when">Дата</label>
        <input id="when" type="date" name="when" min="2000-01-01" class="form-control" value="<?php echo e($project->when); ?>">
    </div>

    <div class="form-group">
        <label for="image">Снимка</label>
        <input id="image" type="file" name="image" class="form-control">
    </div>

    <button type="submit" class="btn btn-primary">Запиши</button>
    <?php echo Form::close(); ?>


    <script>
        $('#description').summernote({
            tabsize: 2,
            height: 150
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>