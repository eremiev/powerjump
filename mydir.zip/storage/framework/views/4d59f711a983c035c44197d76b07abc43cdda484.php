<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="styles/blog.css">
    <link rel="stylesheet" type="text/css" href="styles/blog_responsive.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Home -->

    <div class="home">
        <div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="<?php echo e(url('images/projects2.jpg')); ?>"
             data-speed="0.8"></div>
        <div class="home_container">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="home_content text-left">
                            <div class="home_title">Проекти</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Blog -->

    <div class="blog">

    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Blog Post -->

            <div class="<?php echo e(($loop->iteration  % 2 == 0) ? 'blog_post blog_post_dark' : 'blog_post blog_post_light'); ?>">

                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="blog_post_container">
                                <div class="blog_post_image text-center">
                                    <?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e($image->url); ?>" alt=""/>
                                        <?php break; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="blog_post_content text-center">
                                    <div class="blog_post_title"><a href="#"><?php echo e($project->title); ?></a></div>
                                    
                                    <div class="blog_post_date"><a href="#"><?php echo e($project->when); ?></a></div>
                                    <div class="blog_post_text">
                                        <p><?php echo e(str_limit(strip_tags($project->description),500,'...')); ?></p>
                                    </div>
                                    <div class="button blog_post_button"><a href="#">Прочети повече</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($projects->links('pagination.default')); ?>


    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>