<?php $__env->startSection('header'); ?>
    Събития -> Редакция събитие
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
    <?php echo Form::open(['route' => ['admin.events.update', $event->id],
                           'method' => 'PUT',
                           'class'=>'form-horizontal',
                           'files' => true]); ?>

    <div class="form-group">
        <label for="title">Заглавие</label>
        <input type="text" class="form-control" name="title" id="title" value="<?php echo e($event->title); ?>">
    </div>

    <div class="form-group">
        <label for="description">Описание</label>
        <textarea id="description" name="description"><?php echo e($event->description); ?></textarea>

    </div>

    <div class="form-group">
        <label for="when">Дата</label>
        <input id="when" type="date" name="when" min="2000-01-01" class="form-control" value="<?php echo e($event->when); ?>">
    </div>

    <div class="form-group">
        <label for="when">Проект</label>
        <?php echo e(Form::select('project_id', $projects, $event->project_id, [ 'placeholder' =>'Няма свързан проект', 'class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <label for="image">Снимка</label>
        <input id="image" type="file" name="image" class="form-control">
    </div>

    <button type="submit" class="btn btn-primary">Запиши</button>
    <?php echo Form::close(); ?>


    <script>
        $('#description').summernote({
            tabsize: 2,
            height: 150
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>