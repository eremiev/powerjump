<?php $__env->startSection('header'); ?>
    Партньори
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
    <a href="<?php echo e(URL::route('admin.partners.create')); ?>" class="btn btn-default">Добави нов партньор</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Име</th>
            <th scope="col">Описание</th>
            <th scope="col">Действие</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($partner->id); ?></th>
                <td><?php echo e($partner->name); ?></td>
                <td><?php echo e(str_limit($partner->description, $limit = 100, $end = '...')); ?></td>
                <td class="small">
                    <div class="row">
                        <div class="col-lg-6">
                            <a href="<?php echo e(route('admin.partners.edit', $partner->id)); ?>">
                                <i class="fa fa-pencil" style="font-size:24px" aria-hidden="true"></i>
                            </a>
                        </div>
                        <div class="col-lg-6">
                            <?php echo e(Form::open(['route' => ['admin.partners.destroy', $partner->id], 'method' => 'delete'])); ?>

                            <button type="submit" style="padding: 0;border: none;background: none; cursor: pointer;">
                                <i class="fa fa-trash" style="font-size:24px" aria-hidden="true"></i>
                            </button>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="text-center">
        <?php echo e($partners->render()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>