<?php $__env->startSection('header'); ?>
    Проекти
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
    <a href="<?php echo e(URL::route('admin.projects.create')); ?>" class="btn btn-default">Добави нов проект</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Заглавие</th>
            <th scope="col">Описание</th>
            <th scope="col">Дата</th>
            <th scope="col">Действие</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($project->id); ?></th>
                <td><?php echo e($project->title); ?></td>
                <td><?php echo e(str_limit($project->description, $limit = 100, $end = '...')); ?></td>
                <td><?php echo e($project->when); ?></td>
                <td class="small">
                    <div class="row">
                        <div class="col-lg-6">
                            <a href="<?php echo e(route('admin.projects.edit', $project->id)); ?>">
                                <i class="fa fa-pencil" style="font-size:24px" aria-hidden="true"></i>
                            </a>
                        </div>
                        <div class="col-lg-6">
                            <?php echo e(Form::open(['route' => ['admin.projects.destroy', $project->id], 'method' => 'delete'])); ?>

                            <button type="submit" style="padding: 0;border: none;background: none; cursor: pointer;">
                                <i class="fa fa-trash" style="font-size:24px" aria-hidden="true"></i>
                            </button>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="text-center">
        <?php echo e($projects->render()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>